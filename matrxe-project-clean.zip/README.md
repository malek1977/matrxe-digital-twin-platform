# 🚀 MATRXe - منصة النسخ الرقمية الذكية

## 📖 نظرة عامة
منصة متقدمة لإنشاء نسخ رقمية ذكية باستخدام الذكاء الاصطناعي.

## ✨ المميزات
- إنشاء نسخ رقمية بتقليد الصوت والوجه
- محادثات ذكية ثنائية الاتجاه
- مهام مجدولة تلقائية
- واجهة متعددة اللغات
- نظام دفع مؤجل

## 🏗️ الهيكل التقني
- **Backend:** FastAPI + PostgreSQL
- **Frontend:** React + TailwindCSS
- **AI:** Ollama + ElevenLabs + MediaPipe
- **النشر:** Docker + Nginx

## 🚀 النشر السريع
```bash
# Clone repository
git clone https://github.com/malek1977/matrxe.git
cd matrxe

# Start with Docker
docker-compose up -d

# Access applications
# Frontend: http://localhost:3000
# Backend API: http://localhost:8000
# API Docs: http://localhost:8000/docs
📁 هيكل المشروع
text
MATRXe/
├── backend/          # FastAPI application
├── frontend/         # React application
├── deployment/       # Deployment scripts
├── ai_models/        # AI models and training
├── database/         # Database schemas and migrations
└── documentation/    # Project documentation
📄 الترخيص
MIT License - أنشئه بمحبة ❤️