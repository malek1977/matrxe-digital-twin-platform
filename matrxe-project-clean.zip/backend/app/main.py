from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="MATRXe Digital Twin Platform",
    description="Advanced AI-powered digital twin creation",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {
        "message": "🚀 Welcome to MATRXe - Digital Twin Platform",
        "version": "1.0.0",
        "endpoints": {
            "docs": "/docs",
            "api": "/api/v1",
            "health": "/health"
        }
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "matrxe-backend"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)